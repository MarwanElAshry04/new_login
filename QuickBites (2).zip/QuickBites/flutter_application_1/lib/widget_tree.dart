import 'package:flutter/material.dart';
import 'auth.dart';
import 'pages/home_page.dart';
import 'pages/login_page.dart';

class WidgetTree extends StatefulWidget {
  const WidgetTree({super.key});

  @override
  State<WidgetTree> createState() => _WidgetTreeState();
}

class _WidgetTreeState extends State<WidgetTree> {
  @override
  Widget build(BuildContext context) {
    print("Building WidgetTree...");

    return StreamBuilder(
      stream: Auth().authStateChanges,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          print("Waiting for authentication state...");
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasData) {
          print("User is logged in, navigating to HomePage");
          return HomePage();
        } else {
          print("User is not logged in, navigating to LoginPage");
          return LoginPage();
        }
      },
    );
  }
}
