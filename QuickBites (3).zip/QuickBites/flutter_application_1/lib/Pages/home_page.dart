import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/auth.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  final User? user = Auth().currentUser;

  Future<void> signOut() async {
    print("Signing out...");
    await Auth().signOut();
  }

  Widget _title() {
    return const Text('Welcome to QuickBites!');
  }

  Widget _userUid() {
    print("User email: ${user?.email}");
    return Text(user?.email ?? 'No user found');
  }

  Widget _signOutButton() {
    return ElevatedButton(
      onPressed: signOut,
      child: const Text('Sign Out'),
    );
  }

  @override
  Widget build(BuildContext context) {
    print("Building HomePage...");
    return Scaffold(
      appBar: AppBar(title: _title()),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _userUid(),
            _signOutButton(),
          ],
        ),
      ),
    );
  }
}
