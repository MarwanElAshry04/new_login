import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: "AIzaSyCNaN-SZWIsFhQADLdpTBHVKAJIgyAcqeE",
      authDomain: "codefather-ac293.firebaseapp.com",
      projectId: "codefather-ac293",
      storageBucket: "codefather-ac293.appspot.com",
      messagingSenderId: "569615557410",
      appId: "1:569615557410:web:1f138dd466e6b09690bb7b",
      measurementId: "G-LR8K598L4X",
    );
  }
}
